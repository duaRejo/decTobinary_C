#ifndef header_h 
# define header_h

void flipBits(char* bits);
void addOne(char* bits);
void reverse(char* bits);
char* convertToBinary(int num);

#endif