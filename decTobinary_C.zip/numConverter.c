#include "numConverter.h"

/* Names: Dua Kaurejo, Nick Iverson
   Semester: Spring 2022
   Course: ECE233*/

void flipBits(char* bits){
    for(int i=0;i<33;i++){
        if(bits[i] == '0')
            bits[i] = '1';
        else
            bits[i] = '0';
    }
}

//Adds one to the input binary representation.
void addOne(char* bits){  
    int i = 0;
    int carry = 1;
    do{
        //character '0' has ascii value 48
        int num = (bits[i] - 48) + carry;  
        if (num == 1){
            bits[i] = '1';
            carry = 0;
        }
        else if (num == 2){
            bits[i] = '0';
            carry = 1;
        }
        i++;
    } while(carry == 1 && i <= 31);
    
}
void reverse(char* bits){
   int NUM_BITS = 33;
   int start = 0;
   int end = NUM_BITS - 1;
   while (start < end)
    {
         char temp = bits[start]; 
        bits[start] = bits[end];
        bits[end] = temp;
        start++;
        end--;
    } 
}

char* convertToBinary(int num){
    //Declare and initialize bits on the heap
    char* bits = (char*)malloc(33);
    for(int i = 0; i < 33; i++){
        bits[i] = '0';
    }
    bits[33]= '\0';
    //to binary (unsigned)
    int tmp = abs(num);
    for(int i=(33-1);i>=0;i--){
        if (tmp >= pow(2, i) ){
            bits[i] = '1';
            tmp = tmp - pow(2,i);
        }
    }
   
    //if num is negative, flip bits and add one 
    if(num<0){
        flipBits(bits);
        addOne(bits);
    }
    reverse(bits);
    
    
    return bits;
}