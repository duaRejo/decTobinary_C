/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.
ece233 lab 1

*******************************************************************************/
#include <stdio.h>
#include "numConverter.h"

/* Names: Dua Kaurejo, Nick Iverson
   Semester: Spring 2022
   Course: ECE233*/
   



int main()
{
    
    
 
    
    printf("Enter input file name: "); 
    char input[30]; 
    scanf(" %s", &input);
    
    printf("Enter output file name: "); 
    char output[30]; 
    scanf(" %s", &output);
    
    //Open a file for reading:
    FILE *f = fopen(input, "r");
    
    FILE *f2 = fopen(output, "w");
    int number;
    while(!feof(f)){
        int n = fscanf(f, "%d", &number);
        char* bits2 = convertToBinary(number);
        fprintf(f2, "%s\n", bits2);
        free(bits2);
        
    }
    
    
    
    
    

    
}


